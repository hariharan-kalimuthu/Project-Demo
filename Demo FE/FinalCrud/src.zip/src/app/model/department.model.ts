// src/app/department.model.ts
export class Department {
    departmentID: number;
    departmentName: string;
    location: string;
    constructor() {
        this.departmentID = 0; 
        this.departmentName='';
        this.location='';
    }
  }
  