// src/app/models/employee.model.ts

import { CurrencyPipe, DatePipe, DecimalPipe } from "@angular/common";

export interface Employee {
  employeeId?: number;
  firstName: string;
  lastName: string;
  departmentId: number;
  departmentName?: string;
  location?: string;
  dateOfBirth:Date;
  salary:number;
}
