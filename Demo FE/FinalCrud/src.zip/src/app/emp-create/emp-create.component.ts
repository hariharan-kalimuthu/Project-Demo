import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/employee.model';
import { EmployeeService } from '../employee/employee-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-emp-create',
  templateUrl: './emp-create.component.html',
  styleUrls: ['./emp-create.component.css']
})
export class EmpCreateComponent implements OnInit {
  employees:Employee[]=[];
  formbuilds:FormGroup;
  

  constructor(private employeeService:EmployeeService,private fp:FormBuilder ,private router: Router) { 
    this.formbuilds=this.fp.group({
      employeeId: ['',Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      departmentID: ['', Validators.required],
      salary:['',Validators.required],
      dateOfBirth:['',Validators.required]
    })
  }
  loadEmployees(): void {
    this.employeeService.getEmployees().subscribe((data) => {
      this.employees = data;
    });
  }
  ngOnInit(): void {
  }
  goToEmployeePage() {
    this.router.navigate(['/employee']); // Update the route path as needed
  }
  createEmployee(): void {
    let emp: Employee = {
      firstName: this.formbuilds.get("firstName")?.value,
      lastName: this.formbuilds.get("lastName")?.value,
      departmentId: this.formbuilds.get("departmentID")?.value,
      dateOfBirth: this.formbuilds.get("dateOfBirth")?.value,
      salary: this.formbuilds.get("salary")?.value,
    };
    console.log(emp);
    this.employeeService.createEmployee(emp).subscribe(Response=>{
    this.loadEmployees();
    })
  }
}
