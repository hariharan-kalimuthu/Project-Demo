// employee.component.ts
import { Component, OnInit } from '@angular/core';
import { DepartmentService, EmployeeService } from './employee-service.service';
import { Employee } from '../model/employee.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Department } from '../model/department.model';
//import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html' ,
  styleUrls: ['./employee.component.css'],
})
export class EmployeeComponent implements OnInit {
  departments : Department[]=[];
  employees: Employee[] = [];
  editingEmployee:boolean=false;
  formbuilds:FormGroup;
  constructor(private employeeService: EmployeeService ,private fp:FormBuilder,private departmettservices:DepartmentService) {
    this.formbuilds=this.fp.group({
      employeeId: [0,Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      departmentID: ['', Validators.required],
      salary:['',Validators.required],
      dateOfBirth:['',Validators.required]

    });
  }

  ngOnInit(): void {
    this.loadEmployees();
  }
  Edit():void{
    console.log(this.formbuilds.value);
   this.employeeService.updateEmployee(this.formbuilds.value).subscribe(Response=>{
    this.loadEmployees();
    
   })
   this.editingEmployee=false;
   this.loadEmployees();
  }

  loadEmployees(): void {
    this.employeeService.getEmployees().subscribe((data) => {
      this.employees = data;
    });
  }

  editEmployee(employee: Employee): void {
    this.editingEmployee=true;
    this.formbuilds.patchValue(employee);
    // this.editingEmployee=false;
    this.loadEmployees();
  }
 
  cancelEdit(): void {
    this.editingEmployee=false;
    this.loadEmployees();
  }

  // saveEdit(): void {
  //   if (this.editingEmployee) {
  //     this.employeeService.updateEmployee(this.editingEmployee).subscribe(() => {
  //       this.loadEmployees();
  //       this.cancelEdit();
  //     });
  //   }}

createEmployee(): void {
  console.log(this.formbuilds.value);
  this.employeeService.createEmployee(this.formbuilds.value).subscribe(Response=>{
  
  })
 
}

deleteEmployee(employeeId: number): void {
  this.employeeService.deleteEmployee(employeeId).subscribe({
    next:(data) => {
      console.log(data);
      if(confirm(data)){
        this.loadEmployees();
      }
    }
  });
}
  }
