// employee.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../model/employee.model';
import { Department } from '../model/department.model';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private apiUrl = 'https://localhost:7155/API/Employee';

  constructor(private http: HttpClient) {}
//https://localhost:7155/API/Employee/getemployee
  getEmployee(id: number): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.apiUrl}/getemployee/${id}`);
  }

  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.apiUrl}/getemployee`);
  }

  createEmployee(employee: Employee): Observable<Employee[]> {
    let data = this.http.post<Employee[]>(`${this.apiUrl}/Post`, employee );
    console.log(data, 'Employee Add');
    return data;
  
  }

  updateEmployee(employee: Employee): Observable<Employee[]> {
     let data = this.http.put<Employee[]>(`${this.apiUrl}/Update`, employee);
     console.log(data, 'Employee Update');
     return data;
  }
  // addEmployee(employee: Employee[]): Observable<Employee[]> {
  //   let data = this.http.post<Employee[]>(`${this.apiUrl}/employees`, employee);
  //   console.log(data, 'Employee Add');
  //   return data;

  // }

  deleteEmployee(id: number): Observable<any> {
    let data = this.http.delete(`${this.apiUrl}/Delete/${id}`, {responseType: 'text'});
    console.log(data, 'delete data');
    return data;
  }
}


@Injectable({
  providedIn: 'root',
})
export class DepartmentService {
  private apiUrl = 'https://localhost:7155/API/Department';

  constructor(private http: HttpClient) {}

  getDepartments(): Observable<Department[]> {
    return this.http.get<Department[]>(`${this.apiUrl}/getDepartment`);
  }

  getDepartment(id: number): Observable<Department> {
    return this.http.get<Department>(`${this.apiUrl}/getdepartment/${id}`);
  }

  createDepartment(department: Department): Observable<any> {
    return this.http.post(`${this.apiUrl}/Post`, department,{responseType: 'text'});
  }

  updateDepartment(department: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/update/`, department);
  }

  deleteDepartment(id: number): Observable<any> {
    let data1 = this.http.delete(`${this.apiUrl}/Delete/${id}`, {responseType: 'text'});
    console.log(data1, 'delete data');
    return data1;
  }
}
